/*********************************************************************
 *   Copyright 2010, UCAR/Unidata
 *   See netcdf/COPYRIGHT file for copying and redistribution conditions.
 *********************************************************************/

/* $Id: liblib.c,v 1.2 2010/05/24 19:48:13 dmh Exp $ */
/* $Header: /upc/share/CVS/netcdf-3/liblib/liblib.c,v 1.2 2010/05/24 19:48:13 dmh Exp $ */

/* Only here to keep loader quiet */
int
liblib(void)
{
    return 1;
}

